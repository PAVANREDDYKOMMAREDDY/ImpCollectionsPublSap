package com.sapient.servicedaodemo.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sapient.servicedaodemo.dao.TransactionDAO;
import com.sapient.servicedaodemo.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService{
	
	TransactionDAO transactionDAO;
	private static final String[] blackListEmails=new String[] {"blacklist1@gmail.com","blacklist2@gmail.com",
														"blacklist3@gmail.com","blacklist4@gmail.com"};

	@Autowired
	public TransactionServiceImpl(@Qualifier("transactionDAOImpl") TransactionDAO transactionDao) {
		super();
		this.transactionDAO = transactionDao;
	}

	@Override
	@Transactional
	public List<Transaction> findAllTransactions() {
		// TODO Auto-generated method stub
		return transactionDAO.getAllTransactions();
	}

	@Override
	public String screenTransactionById(int theId) {
		Transaction transaction = transactionDAO.findTransactionById(theId);
		String dateInString = transaction.getDate();
		LocalDate localDate = LocalDate.parse(dateInString);
		LocalDate today = LocalDate.now();
		
		long difference = ChronoUnit.DAYS.between(localDate, today);
		boolean isInBlackList = Arrays.asList(blackListEmails).contains(transaction.getEmail());
		
		if(isInBlackList  && difference < 30)
			return "REJECT";
					
		return "ACCEPT";
	}

	@Override
	@Transactional
	public Transaction findTransactionById(int theId) {
		return transactionDAO.findTransactionById(theId);
	}

	@Override
	@Transactional
	public Transaction saveTransaction(Transaction theTransaction) {
		return transactionDAO.saveTransaction(theTransaction);
	}

	@Override
	@Transactional
	public int deleteTransactionById(int theId) {
		transactionDAO.deleteTransactionById(theId);
		return theId;
	}
	

}
