package com.sapient.servicedaodemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sapient.servicedaodemo.model.Transaction;

@Repository("transactionDAOImpl")
public class TransactionDAOImpl implements TransactionDAO {

	private EntityManager entityManager ;
	
	@Autowired
	public TransactionDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	@Override
	public List<Transaction> getAllTransactions() {
		Query query = entityManager.createQuery("from Transaction");
		List<Transaction> transactions = query.getResultList();	
		return transactions;
	}

	@Override
	public Transaction findTransactionById(int theId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction saveTransaction(Transaction theTransaction) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTransactionById(int theId) {
		Query query = entityManager.createQuery("delete from Transaction where id=: transactionId");
	    query.setParameter("transactionId", theId);
	    query.executeUpdate();
	    

	}

}
