package com.sapient.servicedaodemo.dao;

import java.util.List;

import com.sapient.servicedaodemo.model.Transaction;

public interface TransactionDAO {
	List<Transaction> getAllTransactions();

    Transaction findTransactionById(int theId);

    Transaction saveTransaction(Transaction theTransaction);

    void deleteTransactionById(int theId);
}
